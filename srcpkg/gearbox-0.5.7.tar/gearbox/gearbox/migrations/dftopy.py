#!/usr/bin/env python
'''
Quick hacked-together script to convert a progress .df file containing
ONLY "add" commands into a gearbox migration .py file.
Created: 09/2010 Fabian Kreutz
'''

import sys
import re
import os
import itertools

rules = (
  re.compile('^(?P<type>ADD SEQUENCE) "(?P<name>.*)"$'),
  re.compile('^(?P<type>ADD TABLE) "(?P<name>.*)"$'),
  re.compile('^(?P<type>UPDATE TABLE) "(?P<name>.*)"$'),
  re.compile('^(?P<type>ADD FIELD) "(?P<name>.*)" OF "(?P<table>.*)" AS (?P<datatype>.*)$'),
  re.compile('^(?P<type>ADD INDEX) "(?P<name>.*)" ON "(?P<table>.*)"$'),
  re.compile('^(?P<type>UPDATE INDEX) "(?P<name>.*)" OF "(?P<table>.*)"$'),
)


def read_body(gdict, fiter):
    for subline in fiter:
        if not subline: break
        option = subline.strip().split(' ', 1)
        key = option[0].lower().replace('-', '_')
        value = option[1] if len(option) == 2 else 'True'
        if len(value) > 2:
            value = value[0] + value[1:].replace('""', '%temp%')
        while value.startswith('"') and value.count('"') % 2 == 1:
            value += '\n' + next(fiter).strip().replace('""', '%temp%').replace("'","\\'")
        if value == '?':
            value = 'self.unknown'
        elif value in ['yes', 'no']:
            value = '"%s"' % value
        if value.find('\n') > -1:
            value = value.replace('"', "'''")
        value = value.replace('%temp%', '\\"')
        if key == 'index_field':
            if not key in gdict:
                gdict[key] = []

            value = value.replace('"', '')
            value = value.replace('ASCENDING', '')
            value = value.replace('DESCENDING', 'DESC')
            value = ' '.join(value.split())

            gdict[key].append(value.split(' '))

        elif key == 'table_trigger':
            if not key in gdict:
                gdict[key] = []

            event, override_proc, proceduretext, procedure, crctext, crc = value.split(' ')
            event = event.replace('"', '')
            override_proc = override_proc.replace('"', '')
            procedure = procedure.replace('"', '')
            crc = crc.replace('"', '')

            triggerdict = {}

            if override_proc == 'OVERRIDE':
                triggerdict["override_proc"] = True
            else:
                triggerdict["override_proc"] = False

            triggerdict["crc"] = crc
            triggerdict["procedure"] = procedure
            triggerdict["event"] = event

            gdict[key].append(triggerdict)

        elif key == "lob_size":
            gdict[key] = '"%s"' % value

        else:
            gdict[key] = value


def read_df(filename):
    sequences = []
    tables = {}
    tableupds = {}
    fiter = (x.strip() for x in open(filename))
    for line in fiter:
        if line == '.':
            print('Done')
            break
        for gdict in (mm.groupdict() for mm in (rule.match(line) \
                                                for rule in rules) \
                                     if mm):
            read_body(gdict, fiter)
            if gdict['type'] == 'ADD SEQUENCE':
                sequences.append(gdict)
            elif gdict['type'] == 'ADD TABLE':
                if 'description' in gdict:
                    gdict['desc'] = gdict['description']
                    del gdict['description']
                tables[gdict['name']] = gdict
            elif gdict['type'] == 'UPDATE TABLE':
                tableupds[gdict['name']] = gdict
            elif gdict['type'] == 'UPDATE INDEX':
                if not gdict['table'] in tableupds:
                    tableupds[gdict['table']] = {'name': gdict['table']}
                table = tableupds[gdict['table']]
                table.setdefault(gdict['type'], []).append(gdict)
            else:
                table = tables[gdict['table']]
                table.setdefault(gdict['type'], []).append(gdict)
    return sequences, tables.values(), tableupds.values()


def prelude(classname):
    return ['from gearbox.migrations import Migration\n', '\n',
            'class {0}(Migration):\n'.format(classname), '\n']


indirect_attrs = ['name', 'type', 'table', 'datatype', 'index_field',
                  'ADD FIELD', 'ADD INDEX', 'UPDATE INDEX']
def csv_args(entity):
    args = ['\'{0}\''.format(entity['name'])]
    if 'datatype' in entity:
        args += ['\'{0}\''.format(entity['datatype'])]
    if 'index_field' in entity:
        args += ['{0}'.format(repr(entity['index_field']))]
    args += ['{0}={1}'.format(x, y) for x, y in entity.items() \
                                    if not x in indirect_attrs]
    return ', '.join(args)


def write_sequences(db_name, sequences, filename):
    fd = open(filename, 'wt')
    fd.writelines(prelude('AddSequences'))
    fd.write('    database = "%s"\n\n' % db_name)
    fd.write('    def up(self):\n')
    for seq in sequences:
        fd.write('        self.sequence({0})\n'.format(csv_args(seq)))
    fd.write('\n    def down(self):\n')
    for seq in reversed(sequences):
        fd.write('        self.drop_sequence(\'{0}\')\n'.format(seq['name']))


def write_table(db_name, table, filename):
    fd = open(filename, 'wt')
    fd.writelines(prelude('AddTable{0}'.format(table['name'])))
    fd.write('    database = "%s"\n\n' % db_name)
    fd.write('    def up(self):\n')
    fd.write('        t = self.table({0})\n'.format(csv_args(table)))
    for fld in table.get('ADD FIELD', []):
        fd.write('        t.column({0})\n'.format(csv_args(fld)))
    for idx in table.get('ADD INDEX', []):
        fd.write('        t.index({0})\n'.format(csv_args(idx)))
    fd.write('\n    def down(self):\n')
    fd.write('        self.drop_table(\'{0}\')\n'.format(table['name']))


def write_tableupd(db_name, table, filename):
    fd = open(filename, 'wt')
    fd.writelines(prelude('ChgTable{0}'.format(table['name'])))
    fd.write('    database = "%s"\n\n' % db_name)
    fd.write('    def up(self):\n')
    fd.write('        t = self.alter_table({0})\n'.format(csv_args(table)))
    for idx in table.get('UPDATE INDEX', []):
        fd.write('        t.alter_indexdata({0})\n'.format(csv_args(idx)))
    fd.write('\n    def down(self):\n')
    fd.write('        self.alter_table(\'{0}\')\n'.format(table['name']))
    for idx in table.get('UPDATE INDEX', []):
        fd.write('        t.alter_indexdata({0})\n'.format(idx['name']))


def main(df_file, index=1):
    db_name = os.path.basename(df_file).replace('.df', '')
    sequences, tables, tableupds = read_df(df_file)
    if sequences:
        filename = '{0:04}_add_{1}_sequences.py'.format(index, db_name)
        print('Writing {0} ...'.format(filename))
        write_sequences(db_name, sequences, filename)
        index += 1
    for table in tables:
        filename = '{0:04}_add_table_{1}_{2}.py'.format(index, db_name,
                                                        table['name'].lower())
        print('Writing {0} ...'.format(filename))
        write_table(db_name, table, filename)
        index += 1
    for table in tableupds:
        filename = '{0:04}_update_table_{1}_{2}.py'.format(index, db_name,
                                                        table['name'].lower())
        print('Writing {0} ...'.format(filename))
        write_tableupd(db_name, table, filename)
        index += 1


if __name__ == '__main__':
    assert len(sys.argv) >= 2, 'Syntax: dftopy.py <df-file> [start_idx]'
    args = sys.argv[1:]
    if len(args) == 1:
        main(args[0])
    else:
        main(args[0], int(args[1]))
