import os

class StructureBuilder(object):

    def __init__(self, basedir):
        self.basedir = basedir
        self.areas = []
        self.extents = []
        self.has_bifo = False
        self.has_data = False
        self.directories = set()

    def before_img(self, sizes=(None,), path='bi'):
        self.append_for(sizes, ('b',), path)
        self.has_bifo = True

    def after_img(self, sizes=(None,), path='ai'):
        self.append_for(sizes, ('a',), path)

    def table(self, rpb, bpc=512, name=None, sizes=(None,), path='db'):
        if not self.has_data:
            self.append_schema_area(path)
        if name is None:
            name = '{0}_Data_{1}'.format('Sta' if bpc < 512 else 'Dyn', rpb)
        name = self.uniquify(name)
        self.append_for(sizes, ('d', name, ',{0};{1}'.format(rpb, bpc)), path)

    def index(self, bpc=8, name=None, sizes=(None,), path='ix'):
        assert self.has_data, 'Please add a table area prior to index areas'
        if name is None:
            name = '{0}_Index'.format('Sta' if bpc < 64 else 'Dyn')
        name = self.uniquify(name)
        self.append_for(sizes, ('d', name, ',1;{0}'.format(bpc)), path)

    def append_schema_area(self, path):
        self.append_for((None,), ('d', 'Schema Area', ',64;1'), path)
        self.has_data = True

    def uniquify(self, name):
        number = None
        for aa in self.areas:
            if number is None:
                if aa[0] == name:
                    number = 2
            else:
                if aa[0] == '{0}_{1}'.format(name, number):
                    number += 1
        if number is not None:
            name = '{0}_{1}'.format(name, number)
        return name

    def append_for(self, sizes, data, path):
        dir = self.get_dir(path)
        if isinstance(sizes, int):
            sizes = (sizes, )
        for ss in sizes:
            if ss is None:
                ss = 'v'
            else:
                ss = 'f {0}'.format(ss)
            self.extents.append(data + (dir, ss))
        if data[0] == 'd':
            self.areas.append((data[1], dir, ss))

    def get_dir(self, path):
        if path is None:
            dir = self.basedir
        elif path.startswith('/'):
            dir = os.path.abspath(path)
        else:
            dir = os.path.abspath(os.path.join(self.basedir, path))
        self.directories.add(dir)
        return dir

    def locals(self):
        return {'before_image_area': self.before_img,
                'after_image_area': self.after_img,
                'table_area': self.table,
                'index_area': self.index}

    def validate(self):
        assert self.has_bifo, 'Structure builder does not define any bifo area'
        assert self.has_data, 'Structure builder does not define any data area'

    def as_structure_file(self):
        self.validate()
        result = []
        last_type = 'b'
        for ee in self.extents:
            if last_type != ee[0]:
                result.append('#\n')
                last_type = ee[0]
            if ee[0] in 'ab':
                result.append('{0} {1} {2}\n'.format(*ee))
            else:
                result.append('{0} "{1}"{2} {3} {4}\n'.format(*ee))
        return result

    def as_extent_add(self):
        result = []
        for aa in (x for x in self.areas if x[-1] != 'v'):
            result.append('#d "{0}" {1} {2}\n'.format(*aa))
        return result

    def _ensure_exists(self, dir):
        if not os.path.exists(dir):
            self._ensure_exists(os.path.dirname(dir))
            os.mkdir(dir)

    def read_definition_file(self, definition_file):
        exec(open(definition_file).read() + '\n', globals(), self.locals())

    def write_files(self, db_name):
        db_base = os.path.join(self.basedir, db_name)
        open(db_base + '.st', 'wt').writelines(self.as_structure_file())
        open(db_base + '_add.st', 'wt').writelines(self.as_extent_add())

    def make_directories(self):
        for dir in self.directories:
            self._ensure_exists(dir)

