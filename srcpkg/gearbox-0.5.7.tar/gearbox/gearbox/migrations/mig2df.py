#!/bin/env python

import sys
import os
import tempfile
from gearbox.migrations.migration import Migration
from gearbox.migrations.dumpfile_formatter import DumpfileFormatter
from gearbox.migrations.hr_formatter import HumanReadableFormatter
try:
    from importlib import import_module
except ImportError:
    import_module = __import__

err = sys.stderr

def instantiate_mig(migfile, a2t_cache, a2t_getter, environment):
    migbase = os.path.basename(migfile).split('.')[0]
    mignum, migname = migbase.split('_', 1)
    mignum = 0 if mignum == 'monthly' else int(mignum)
    sys.path.insert(0, os.path.dirname(migfile))
    try:
        locals = import_module(migbase)
    except SyntaxError as se:
        _type, line, _char, excerpt = se.args[1]
        raise Exception('Syntax error in line %d of migration %s:\n%s' % \
                            (line, migbase, excerpt))
    finally:
        sys.path.pop(0)
    for k, v in locals.__dict__.items():
        if k.startswith('__'): continue
        if issubclass(v, Migration) and v != Migration:
            mig = v(mignum, migname, a2t_cache, a2t_getter,
                    environment == 'development')
            return mig
    raise Exception("No Migration defined in file")


def temp_df_file_with(actions, encoding):
    if sys.version_info[0] >= 3:
        df_file = tempfile.NamedTemporaryFile(suffix='.df',
                                              encoding=encoding, mode='wt+')
    else:
        df_file = tempfile.NamedTemporaryFile(suffix='.df')
    df_file.write(DumpfileFormatter().format_df(actions) + '\n')
    df_file.flush()
    return df_file


def mig2df(migration_file, direction, a2t_cache, a2t_getter, environment):
    """Write schema change commands into .df file and return a handle.
    a2t_cache is a dictionary, with a2t_data for each database.
    If the migration's database is not found, a2t_getter is used to create
    that data. After the call, the cache will contain the changes that
    this migration did."""
    assert environment in ['development', 'production'], \
           'Unknown environment: {0}'.format(environment)
    assert os.path.exists(migration_file), \
           'Migration {0} does not exist'.format(migration_file)
    assert os.access(migration_file, os.R_OK), \
           'Migration {0} not readable'.format(migration_file)

    migration = instantiate_mig(migration_file, a2t_cache, a2t_getter,
                                environment)
    err.write('{0}grading migration {1}: {2}\n'.format(direction.capitalize(),
                                             migration.num,
                                             migration.__class__.__name__))
    actions = migration._migrate(direction)
    if not actions:
        return (None, migration.database)
    if hasattr(migration, 'dumped_on') \
    and getattr(migration, 'dumped_on') == os.uname()[1]:
        err.write('This migration was dumped here - skipping\n')
        return (None, migration.database)

    err.write(HumanReadableFormatter().show_steps(actions))

    return (temp_df_file_with(actions, migration.encoding), migration.database)


def split_a2t_data(data):
    result = []
    for line in (x.strip() for x in data):
        if line.count(',') == 2:
            line += ','
        if line.startswith('WARNING') or line.count(',') < 3:
            print(line)
            continue
        type, name, rpb, tables = line.split(',', 3)
        tables = tables.split(',') if tables else []
        result.append({'TYPE': type, 'NAME': name,
                       'RPB': int(rpb), 'TABLES': tables})
    return result


def a2t_file_reader(directory):
    def get_a2t_data(database):
        a2t_file = open(os.path.join(directory, database + '.a2t'), mode='rt')
        return split_a2t_data(a2t_file.readlines())
    return get_a2t_data
        

if __name__ == '__main__':
    migration_file, direction, cache_dir = sys.argv[1:4]
    sys.stdout.write(mig2df(migration_file, direction,
                     {}, a2t_file_reader(cache_dir),
                     os.environ.get('ENVIRONMENT', 'development').read()))
