#!/usr/bin/python
'''
Installation script meant for use via the PyCCBS
'''

import os
import subprocess
relpath = '../..'

if os.path.exists(relpath + '/etc/make_site.py'):
    exec(open(relpath + '/etc/make_site.py').read())
else:
    rpcs = dict((x.split(':') for x in os.environ.get('RPCS', '').split(',')))
    appname = os.environ.get('CUSTOMER', 'tms')

tools_dir = os.environ['PREFIX']
project_root = os.path.abspath(os.path.join(tools_dir, '..'))

os.symlink('.', 'fcgi_agent')
subprocess.call(['make', 'install_fcgi_agent_lib', '--quiet',
                        'CUSTOMER=' + appname,
                        'RPCS=' + ','.join(rpcs.keys()),
                        'LIB_PREFIX=%s/fcgi_agent' % tools_dir,
                        'STATE_DIR=%s/var' % project_root,
                        'DLC_PATH=%s' % os.environ['DLC'],
                        'SERVER_DEFAULT_TIMEZONE=timezone',
                        'TEMPDIR=%s/var/tmp' % project_root
                ])
