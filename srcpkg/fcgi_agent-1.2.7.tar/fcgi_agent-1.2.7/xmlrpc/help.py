import re
import os

class DocTable(list):

    def __init__(self, data):
        data = data.strip()
        if not data.startswith('@'):
            raise 'Not a DocTable definition'
        if not data.count(' '):
            self.title = data[1:]
            self.maxcols = 1
            self.data = []
            return
        title, data = data.split(' ', 1)
        self.title, data = title[1:], [l.strip() for l in data.split('\n')]
        self.maxcols = max([l.count(';') for l in data])
        self.data = [(l + (self.maxcols - l.count(';'))*';').split(';') \
                     for l in data]

    def to_confluence(self):
        result = '||%s||%s\n' % (self.title, self.maxcols*' ||')
        data = [' |'.join([f.replace('|', '\|') for f in l]) \
                for l in self.data]
        result += '\n'.join(['|%s |' % l for l in data])
        return result

    def __str__(self):
        result = self.title.upper() + ':\n'
        for line in self.data:
            result += '  %18s  %10s  %s\n' % (line[0], line[1], \
                                              ' '.join(line[2:]))
        return result



class DocFile(object):

    doc_re = re.compile('/\*\*\s*((?:[^*]|\*[^/])*)\*/', re.S|re.M)
    var_re = re.compile('^&SCOPED-DEFINE +(\w+) +(.+)$', re.M)

    def __init__(self, filename):
        self.filename = filename
        self.modulename = os.path.basename(filename).replace('.p', '').\
                                                     replace('__', '.')
        self.data = None

    def to_confluence(self):
        data = self.get_data()
        result = 'h2. %s\n' % self.modulename
        if not data:
            print('No documentation comment found in %s' % self.filename)
            return result + 'No docs found\n\n'
        for line in data:
            if isinstance(line, DocTable):
                result += line.to_confluence() + '\n\n'
            else:
                result += line + '\n'
        return result + '\n\n'

    def __str__(self):
        return '\n'.join([str(l) for l in self.get_data()]) + '\n\n'

    def get_data(self):
        if self.data is None:
            self.data = []
            fileconts = open(self.filename).read()
            match = self.doc_re.search(fileconts)
            if not match:
                return []
            ppsymbols = {}
            for k, v in self.var_re.findall(fileconts):
                ppsymbols[k] = v
            fileconts = match.group(1)
            if fileconts.count('%('):
                fileconts = fileconts % ppsymbols
            for line in [l.strip() for l in fileconts.split('*')]:
                if line.startswith('@'):
                    self.data.append(DocTable(line))
                else:
                    self.data.append(line)
        return self.data

if __name__ == '__main__':
    import sys
    print(str(DocFile(sys.argv[1])))
