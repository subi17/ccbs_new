# fcgi\_agents - fcgi from Progress OE(tm) but also the XMLRPC

First there is the licensing issue.
Running Progress' App-Server is very costly, so implementing a daemon that understands fcgi saves some 10.000s Euro per month in user licensing.

Secondly, at least back then, it was not easy to integrate with Progress.
For the new and innovative Ruby-on-Rails based web-app "Newton" to get data, we needed to interact with TMS, and for that we have the XMLRPC.

Since then it has been strongly used in Telefinland, Yoigo, Aina, Academica (for almost all RoR-TMS communication) and in more modern customers (DNA, Orange) for the synchronous ones.

I always suggested Quiver/Thrift as alternative, but this one works.

## Overview

This is a XMLRPC server for Progress OpenEdge(tm).

It uses a C-based fcgi-library (dynamic binding from 4GL) to read and write from a socket and calls the main loop.
If that main loop uses XMLRPC, then it can deserialize the XML into a temp-table structure and call external procedures as handlers of the request.

## TODOs

This is a very old tool.  The best TODO I can tell you is: replace it.
However it works and is heavily used in several customers.

It does not have tests, but it integrates with gearbox to unit-test the procedures.
Since there is virtually no development going on and it should be rather completely substituted, I doubt the usefulness of implementing comprehensive tests.

To substitute it:
 * use JsonRPC instead XML. XML is like violence! (If it does not solve the problem: use more of it)
 * use quiver (my thrift implementation)
 * go object oriented. There is a branch for this, but it never got deployed

Another TODO is the integration with the authentication.
I believe it was half-heartedly patched in for yoigo at some point, but it's not uniformely used and so can cause compilation errors and such.

## Now when are you actually documenting the code, dammit?

I've helt plenty of tutorials about the fcgi\_agents.
All participants forgot about the contents in a matter of days afterwards.
I found an old workshop file from pre-2011 (at that time I changed computer and so all timestamps were reset) and add it here to the repository.

Just last summer I documented it more thoroughly on luna:
  [Tool fcgi_agents](https://luna.qvantel.net/display/DEV/Tool+FcgiAgents)
Just in case, I copied the contents of that page here, as well.

The file [install](./INSTALL) tells you a bit, too.

Experience has shown that the fcgi\_agents are rather low-level for which most
people don't have any patience.  So don't expect too much of this.
Maybe it's not the documentation, maybe it's you!

But here it comes:

As INSTALL tells you, you need to put some basic configuration into site.mk.
Make will then substitute the appropriate variables in all those .in files.

You will want to have one main executable, which is either `nq_xmlrpc.p` or
`nq_other.p`.
Check their code, they are very short and only implement the main endless loop.
They use **fetchRequest** and **sendResponse**, which are provided by
`nq_4glconn.i` - the include that binds 4GL together with the shared library (.so).

The "other" loop simply runs the procedure file `@NAME@_process`, which you
need to configure in site.mk and implement yourself.

The "xmlrpc" loop includes the `xmlrpc_server.i` includes, which will still
process the request further, before delegating to a handler.

 * using the SAX parser to parse the request payload
 * populating some global variables (gcMethodName) and a temp table with the parameters
 * if there was no parsing error, run the procedure mentioned as method name
 * if there was still no error, serialize the outbound part of the temptable into the payload XML.
 * sent status code and payload back.

Please check other documentation about the access methods of that temp table (`xmlrpc_access.i`).

There isn't really much more than that.
Don't be shy, jump into the code!  God bless!
