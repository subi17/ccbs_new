#!/usr/bin/env python

import os, shutil
from subprocess import Popen, PIPE
import tempfile

skip_srcpkg_check = True
relpath = '../..'

if os.path.exists(relpath + '/etc/make_site.py'):
    exec(open(relpath + '/etc/make_site.py').read())
else:
    raise IOError('File {0} not found'.format(relpath + '/etc/make_site.py'))

install_dir = os.environ.get('PREFIX')
os.environ['PROPATH'] = '.,{0},{0}/stompAdapter'.format(install_dir)
#os.environ['TERM'] = 'xterm'

def mkdir_p(directory):
    try:
        os.makedirs(directory)
    except OSError as exc:  # Python >2.5
        if exc.errno == errno.EEXIST and os.path.isdir(directory):
            pass
        else:
            raise

def update_hpdenvironment_file(filepath):
    with open(filepath, 'wt') as fd:
        fd.write('&IF "{&HPDEnvironment}" NE "YES"\n')
        fd.write('&THEN\n')
        fd.write('&GLOBAL-DEFINE HPDEnvironment YES\n')
        fd.write('&GLOBAL-DEFINE HPD_ENVIRONMENT {0}\n'.format(appname))
        fd.write('&ENDIF\n')

pfile = tempfile.NamedTemporaryFile(suffix='.p', mode='wt')
pfile.write('ROUTINE-LEVEL ON ERROR UNDO, THROW.\n')

for base, dirs, files in os.walk('HPD'):
    mkdir_p(os.path.join(install_dir, base))
    for file in files:
        if file.endswith('.cls') or file.endswith('.p'):
            pfile.write('COMPILE %s SAVE INTO %s.\n' % \
                               (os.path.join(base, file),
                                install_dir))
        elif not file.endswith('.i'):
            shutil.copyfile(os.path.join(base, file),
                            os.path.join(install_dir, base,file))
        elif file == 'HPDEnvironment.i':
            update_hpdenvironment_file(os.path.join(base, file))
        elif file == 'HPDConst.i':
            if not os.path.exists(work_dir + '/tms/HPD/' + file):
                mkdir_p(work_dir + '/tms/HPD')
                shutil.copy2(os.path.join(base, file), work_dir + '/tms/HPD/' + file)
            else:
                shutil.copy2(work_dir + '/tms/HPD/' + file, os.path.join(base, file))
pfile.flush()
out = Popen(mpro + ['-b', '-p', pfile.name], stdout=PIPE)
errors = out.stdout.read()
if errors:
    raise Exception(errors)
