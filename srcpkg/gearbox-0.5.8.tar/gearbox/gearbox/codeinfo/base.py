import re, os
import subprocess
import tempfile

try:
    next
except NameError:
    def next(gen): return gen.next()

mpro = None

class Callable(object):
    def __init__(self, name):
        self.name = name
        self.parameters = []
        self.return_value = None
        self.signature = None
        self.body = None
        self.doc = None

    def parse_parameters(self, args):
        for param in (x.split(' ') \
                      for x in args.strip().split(',') \
                      if x):
            if len(param) > 3 and param[3] == 'EXTENT':
                param.append(-1)
                param = param[0:3] + [int(param[4])]
            self.parameters.append(tuple(param))


class Procedure(Callable):
    prelude = None

class Method(Callable):
    visibility = None
    override = False
    static = False

class Function(Callable):
    pass

class SourceInfo(object):
    _file_ram = {}
    procedure_re = re.compile('\s*procedure', re.I)
    param_def_re = re.compile('\s*def.*put\s+param', re.I)
    prelude_re = re.compile('^(ROUTINE-LEVEL|USING) ', re.I)
    def __init__(self, app_dir, filename):
        self.type = filename.split('.')[-1]
        self.app_dir = app_dir
        self.full_path = os.path.join(app_dir, filename)
        self.global_transaction = None
        self.includes = []
        self.runs = []
        self.callables = None

        if self.type == 'p':
            self.callables = Procedure(filename)
            p = self.callables
            paramdef_linenumbers = []
            for _orig, line, cmd, args in self.xref():
                if cmd == 'PROCEDURE':
                    for x in range(args.count(',') - 1):
                        paramdef_linenumbers.pop()
                elif cmd == 'DEFINITION':
                    paramdef_linenumbers.append(line)
                elif cmd == 'INCLUDE':
                    if args.find('&') > -1:
                        args = args.strip()[1:-1].replace('""', '"')
                        self.includes.append(tuple(args.split(' ', 1)))
                    else:
                        self.includes.append((args.strip(), ''))
                elif cmd == 'RUN':
                    args = args.strip()
                    if not args in self.runs:
                        self.runs.append(args)
            p.signature = []
            p.prelude = []
            p.body = []
            last_added_to = p.prelude
            fileiter = enumerate(self.fileram(os.path.abspath(self.full_path)))
            for lineno, line in fileiter:
                # This is not foolproof! It does not consider tokens in strings
                # and will eat up lines like "cmt */ statement /* new cmt"
                while line.count('/*') > line.count('*/'):
                    line += next(fileiter)[1]
                if lineno in paramdef_linenumbers:
                    p.signature.append(line)
                    last_added_to = p.signature
                elif line.strip().startswith('/*') or not line.strip():
                    last_added_to.append(line)
                elif last_added_to == p.prelude \
                and self.prelude_re.match(line):
                        p.prelude.append(line)
                else:
                    p.body.append(line)
                    last_added_to = p.body
            if p.signature:
                proc = tempfile.NamedTemporaryFile(suffix='.p', mode='wt')
                proc.writelines(['PROCEDURE pp:\n'] + p.signature + ['END.\n'])
                proc.flush()
                for _o, _ln, cmd, args in self.xref(proc.name):
                    if cmd == 'PROCEDURE':
                        assert args.startswith('pp,,')
                        p.parse_parameters(args[4:].strip())
            p.prelude = ''.join(p.prelude).strip()
            p.signature = ''.join(p.signature).strip()
            p.body = ''.join(p.body).strip()
            p.return_value = 'CHARACTER'

        elif self.type == 'i':
            self.callables = []
            for orig, line, cmd, args in self.xref():
                if cmd == 'INCLUDE':
                    if args.find('&') > -1:
                        args = args.strip()[1:-1].replace('""', '"')
                        self.includes.append(tuple(args.split(' ', 1)))
                    else:
                        self.includes.append((args.strip(), ''))
                elif cmd == 'PROCEDURE':
                    name, _dunno, params = args.strip().split(',', 2)
                    p = Procedure(name)
                    p.parse_parameters(params)
                    p.return_value = 'CHARACTER'
                    p.prelude = ''
                    fileiter = iter(self.fileram(orig)[:line + 1])
                    for pline in fileiter:
                        if pline.strip().upper().startswith('PROC'):
                            p.signature = [pline]
                            break
                    p.body = []
                    for pline in fileiter:
                        while pline.count('/*') > pline.count('*/'):
                            pline += fileiter.next()[1]
                        if self.param_def_re.match(pline):
                            p.signature.append(pline)
                        else:
                            p.body.append(pline)
                    p.signature = ''.join(p.signature).strip()
                    p.body = ''.join(p.body).strip()
                    self.callables.append(p)
                elif cmd == 'FUNCTION':
                    name, retval, params = args.strip().split(',', 2)
                    p = Function(name)
                    p.parse_parameters(params)
                    p.return_value = retval.upper()
                    fileiter = iter(self.fileram(orig)[:line + 1])
                    p.body = ''
                    for pline in fileiter:
                        if pline.strip().upper().startswith('FUNC'):
                            while pline.find(')') == -1:
                                pline += next(fileiter)
                            p.signature = pline.strip()
                            p.body = ''
                        else:
                            p.body += pline
                    p.body = p.body.strip()
                    self.callables.append(p)

    definition_re = 'def.*param.*%s\s.*(as|like)'

    def xref(self, file=None):
        xref_file = tempfile.NamedTemporaryFile(mode='wt+')
        proc = tempfile.NamedTemporaryFile(suffix='.p', mode='wt+')
        proc.write('COMPILE %s XREF %s\n' % (file or self.full_path,
                                             xref_file.name))
        proc.flush()
        subprocess.call(mpro + ['-b', '-p', proc.name])
        proc.close()
        for line in xref_file:
            _file, occfile, line, cmd, params = line.split(' ', 4)
            line = int(line) - 1
            if cmd == 'STRING':
                params = params.split('"')[1]
                if re.search(self.definition_re % params,
                             self.fileram(occfile)[line], re.I):
                    cmd = 'DEFINITION'
            if cmd not in ['COMPILE', 'CPINTERNAL', 'CPSTREAM', 'STRING']:
                yield (occfile, line, cmd, params)

    def fileram(self, filename):
        if not filename in self._file_ram:
            self._file_ram[filename] = open(filename, 'rt').readlines()
        return self._file_ram[filename]

# TODO: global-defines

def repository_walker(app_dir):
    for basedir, directories, files in os.walk(app_dir):
        if basedir == '' \
        or base_dir.startswith('test') \
        or base_dir.startswith('scripts'):
            next
        files_gen = (SourceInfo(app_dir, os.path.join(basedir, x)) \
                     for x in files \
                     if x.split('.')[-1] in ['p', 'cls', 'i'])
        yield (basedir, files_gen)
