
# [1] http://www.proxcom.com/600-610-627/dcblkbyte
# [2] http://www.unixtutorial.org/2008/04/default-block-size-in-unix/

class AreaFinder():
    real_block_size = {1: 944, 2: 1968, 4: 4016, 8: 8048}  # See [1]
    def __init__(self, data, blocksize=8):
        self.blocksize = blocksize
        self.data = data

    def area_for_entity(self, tbl, idx=None, simul=[]):
        """Returns the best fitting area name for a given table or index.
        As a side-effect, it puts the entity's name into the area's list."""

        if idx is None:
            size = sum((self.approximate_field_size(x) \
                        for x in tbl['FIELD']), 12)
        else:
            idx_field_names = [y[0] for y in idx['INDEX-FIELD']]
            size = sum((self.approximate_field_size(x) \
                        for x in tbl['FIELD'] \
                        if x['NAME'] in idx_field_names), 4)
        rbs = self.real_block_size[self.blocksize]

        possible_areas = []
        for area in self.data():
            index_area = area.get('TYPE') == 'INDEX'
            if idx and not index_area or not idx and index_area: continue
            records_per_block = int(area['RPB'] or '32')
            max_usage = records_per_block * size
            wastage = abs(rbs - max_usage)
            conflict_tbls = sum((1 for x in simul if x in area['TABLES']))
            possible_areas.append((area['NAME'], wastage,
                                  len(area['TABLES']), conflict_tbls))
        if not possible_areas:
            raise Exception('No possible area found for ' + \
                                (idx or tbl)['NAME'])
        possible_areas.sort(key=lambda x: self.grade_waste_conflict(*x))
        result = possible_areas[0][0]
        for area in self.data():
            if area['NAME'] == result:
                if idx:
                    area['TABLES'].append(idx['NAME'])
                else:
                    area['TABLES'].append(tbl['NAME'])
        return result


    simple_maps = {'integer': 4,
                   'recid': 4,
                   'decimal': 6,    # variable, 6 might be an average
                   'date': 3,
                   'datetime': 7,
                   'datetime-tz': 13,
                   'logical': 2,
                   'int64': 8,
                   'raw': 1024}

    def approximate_field_size(self, field):
        dt = field['DATA-TYPE']
        size = 4
        if self.simple_maps.get(dt):
            size += self.simple_maps.get(dt)
        elif dt == 'character':
            if field.get('FORMAT') is not None:
                if field['FORMAT'].startswith('x('):
                    size += int(field['FORMAT'][2:-1])
                else:
                    size = len(field['FORMAT'])
            else:
                size += 8
        elif dt.endswith('lob'):
            size += field['LOB-BYTES']
        else:
            raise Exception("Don't know size of datatype " + dt)
        if field.get('EXTENT') is not None:
            size *= int(field['EXTENT'])
        return size

    def grade_waste_conflict(self, name, waste, fill, conflicts):
        if name == 'Schema Area': conflicts += 100
        return waste + (conflicts * 100) + (fill * 20)

