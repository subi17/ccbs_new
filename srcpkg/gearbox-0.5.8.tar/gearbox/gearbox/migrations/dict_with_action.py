class DictWithAction(object):
    def __init__(self, name, action, **args):
        self.data = {'TYPE': self.type, 'NAME': name}
        for k, v in args.items():
            self.data[k.replace('_', '-').upper()] = v
        self.action = action
    def __getitem__(self, key):
        return self.data[key]
    def get(self, key, default=None):
        return self.data.get(key, default)
    def keys(self):
        return self.data.keys()

