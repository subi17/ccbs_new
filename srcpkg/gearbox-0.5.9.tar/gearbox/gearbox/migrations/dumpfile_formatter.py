import sys
from .dict_with_action import DictWithAction
from gearbox.migrations.migration import Migration

class DumpfileFormatter():
    '''Formatter for progress-readable dump or structure files (.df/.st).
    It's only internally used for db creation (.st from StructureConfig) and
    migrations (.df from Migration).'''

    def _pvalue(self, value):
        if isinstance(value, bool):
            return ['no', 'yes'][value]
        elif isinstance(value, int):
            return str(value)
        elif value is NotImplemented:
            return '?'
        elif value is None:
            return ''
        else:
            return '"%s"' % value.replace('"', '""')

    def render_entity(self, item, action):
        '''Render one entity (sequence, table, field or index) of a dump file.
        For tables only the header is rendered, no sub-entities.'''
        at = {'create': 'ADD', 'alter': 'UPDATE', 'drop': 'DELETE',
              'rename': 'RENAME', 'setpri':'UPDATE PRIMARY', 'alterdata': 'UPDATE'}
        txt = '%s %s "%s"' % (at[action], item['TYPE'], item['NAME'])
        result = ''
        if item['TYPE'] == 'FIELD':
            txt += ' OF "%s"' % item['TABLE']
            if action == 'create':
                txt += ' AS %s' % item['DATA-TYPE']
            elif action == 'rename':
                txt += ' TO "%s"' % item['NEWNAME']
        else:
            if action == 'rename':
                txt += ' TO "%s"' % item['NEWNAME']
            if item['TYPE'] == 'INDEX':
                if action == 'alterdata':
                    txt += ' OF "%s"' % item['TABLE']
                else:
                    txt += ' ON "%s"' % item['TABLE']

        result += txt + '\n'
        for attr in sorted(item.keys()):
            if attr in ['TYPE', 'NAME', 'TABLE', 'DATA-TYPE',
                        'FIELD', 'INDEX', 'NEWNAME']:
                continue
            elif attr == 'INDEX-FIELD':
                for indf in item[attr]:
                    if len(indf) == 3:
                        result += '  INDEX-FIELD "%s" %s %s\n' % tuple(indf)
                    else:
                        result += '  INDEX-FIELD "%s" %s\n' % tuple(indf)
            elif attr == 'TABLE-TRIGGER':
                for tr in item[attr]:
                    if not tr['event'].upper() in ['CREATE', 'WRITE', 'DELETE',
                                                   'FIND', 'REPLICATION-CREATE',
                                                   'REPLICATION-WRITE',
                                                   'REPLICATION-DELETE']:
                        raise Exception('Invalid trigger event `{0}` '.format(tr['event']))
                    if not tr['override_proc']:
                        override_param = "NO-OVERRIDE PROCEDURE"
                    else:
                        override_param = "OVERRIDE PROCEDURE" #default

                    if tr['crc'] != "?":
                        raise Exception('Trigger CRC should be "?". Check OpenEdge doc or use Data dict tool.')

                    result += '  {0} "{1}" {2} "{3}" {4} "{5}" \n'.format(attr,
                                                                          tr['event'],
                                                                          override_param,
                                                                          tr['procedure'],
                                                                          "CRC",
                                                                          tr['crc'])
            elif attr == 'LOB-SIZE':
                result += '  %s %s\n' % (attr, item[attr])
            elif attr == 'INITIAL' and item[attr] == Migration.unknown:
                result += '  %s %s\n' % (attr, '?')
            else:
                result += '  %s %s\n' % (attr, self._pvalue(item[attr]))
        return result + '\n'


    def format_df(self, data):
        '''format_df(data) -> str
        Formats the data as .df file. The items of the data are expected
        to be DictWithAction types, as produced by the migrations.'''
        result = ''
        for item in data:
            assert item['TYPE'] != 'AREA', "Can't format st as df"
            action = item.action if isinstance(item, DictWithAction) else 'create'
            if action != 'alter' or item['TYPE'] != 'TABLE' \
            or ([x for x in item.data.keys() \
                   if x not in ['INDEX', 'FIELD', 'NAME', 'TYPE']]):
                # table alter only dumped when table-attr is changed (eg. help)
                result += self.render_entity(item, action)
            if item['TYPE'] == 'TABLE':
                for ff in item['FIELD']:
                    result += self.render_entity(ff, ff.action)
                for ii in item['INDEX']:
                    result += self.render_entity(ii, ii.action)
        return result

