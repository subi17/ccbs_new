from .dict_with_action import DictWithAction

class HumanReadableFormatter():
    '''Formatter for human readable output during migration processing.'''

    def show_steps(self, data):
        '''show_steps(data)
Renders the migration's df (as DictWithAction) in human-readable form.'''
        result = ''
        for item in data:
            assert isinstance(item, DictWithAction)
            action, type, name = (item.action.capitalize(),
                                  item['TYPE'].lower(),
                                  item['NAME'])

            result += '  %s %s %s' % (action, type, name)
            if type == 'table':
                if item.action == 'rename':
                    result += ' -> ' + item['NEWNAME'] + '\n'
                elif item.action != 'drop':
                    result += ' (\n'
                    dir = {'create': ' + ' if item.action == 'alter' else '',
                           'alter': '<> ',
                           'alterdata': '<> ',
                           'rename': '   ',
                           'setpri': '1! ',
                           'drop': ' - '}
                    for fi in item['FIELD'] + item['INDEX']:
                        result += '    ' + dir[fi.action]
                        result += fi['TYPE'].lower() + ' '
                        result += fi['NAME']
                        if fi.get('DATA-TYPE'):
                            result += ': ' + fi['DATA-TYPE']
                        if fi.get('NEWNAME'):
                            result += ' -> ' + fi['NEWNAME']
                        result += '\n'

                    if 'TABLE-TRIGGER' in item.keys():
                        for tr in item['TABLE-TRIGGER']:
                            if not tr['override_proc']:
                                override_param = "NO-OVERRIDE PROCEDURE"
                            else:
                                override_param = "OVERRIDE PROCEDURE" #default
                            result += '    trigger {0} {1} "{2}" {3} "{4}" \n'.format(tr['event'],
                                                                                      override_param,
                                                                                      tr['procedure'],
                                                                                      "CRC",
                                                                                      tr['crc'])
                    result += '  )\n'
                else:
                    result += '\n'
            else:
                result += '\n'
        return result
