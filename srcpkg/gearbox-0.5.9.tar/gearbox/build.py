#!/usr/bin/env python

import os, shutil
from subprocess import Popen, PIPE
import py_compile
import tempfile

dlc = os.environ.get('DLC', '/opt/dlc/102a')
install_dir = os.environ.get('PREFIX', 'dist')
os.environ['PREFIX'] = install_dir
os.environ['TERM'] = 'xterm'
os.environ['display_banner'] = 'no'

def ensure_installdir(dirname):
    print('Building %s...' % dirname)
    dirname = os.path.join(install_dir, 'gearbox', dirname)
    for ii in range(dirname.count(os.path.sep) + 1):
        cdir = os.path.sep.join(dirname.split(os.path.sep)[:ii+1])
        if cdir == '': continue         # absolute path -> /
        if not os.path.exists(cdir):
            os.mkdir(cdir)

def install_extras(mod):
    ensure_installdir(mod)
    manifest = os.path.join('gearbox', mod, 'MANIFEST')
    extras = []
    if os.path.exists(manifest):
        extras = [x.strip() for x in open(manifest).readlines()]
        for file in extras:
            file = os.path.join('gearbox', mod, file)
            target = os.path.join(install_dir, file)
            shutil.copy(file, target)
    return extras

def install_progress_module(mod):
    extras = install_extras(mod)
    pfile = tempfile.NamedTemporaryFile(suffix='.p', mode='wt')
    pfile.write('ROUTINE-LEVEL ON ERROR UNDO, THROW.\n')
    for ablsource in os.listdir('gearbox/' + mod):
        if ablsource in extras: continue
        if ablsource.endswith('.cls') or ablsource.endswith('.p'):
            ablsource = os.path.join('gearbox', mod, ablsource)
            pfile.write('COMPILE %s SAVE INTO %s.\n' % (ablsource, install_dir))
    pfile.flush()
    out = Popen([dlc+'/bin/mpro', '-b', '-p', pfile.name], stdout=PIPE)
    errors = out.stdout.read()
    if errors:
        raise Exception(errors)

def install_python_module(mod):
    install_extras(mod)
    sources = [os.path.join('gearbox', mod, x) \
               for x in os.listdir('gearbox/' + mod) \
               if x.endswith('.py')]
    for ii in range(mod.count(os.path.sep) + 1):
        pathpart = mod.split(os.path.sep)[:ii] + ['__init__.py']
        sources.append(os.path.join('gearbox', *pathpart))
    for pysource in sources:
        pytarget = os.path.join(install_dir, pysource) + \
                                (__debug__ and "c" or "o")
        py_compile.compile(pysource, pytarget, doraise=True)
        shutil.copy(pysource, pytarget[:-1])


install_python_module('migrations')
install_progress_module('migrations')
install_python_module('codeinfo')
install_progress_module('fixtures')
install_progress_module('functional')
install_progress_module('unit')
install_progress_module('daemons')
