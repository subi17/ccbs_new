#!/usr/bin/env python

import os, shutil
from subprocess import Popen, PIPE
import tempfile

dlc = os.environ.get('DLC', '/opt/dlc/111')
install_dir = os.environ.get('PREFIX', 'dist')
os.environ['PREFIX'] = install_dir
os.environ['PROPATH'] = '.'
os.environ['TERM'] = 'xterm'
os.environ['display_banner'] = 'no'

def ensure_installdir(dirname):
    dirname = os.path.join(install_dir, dirname)
    for ii in range(dirname.count(os.path.sep) + 1):
        cdir = os.path.sep.join(dirname.split(os.path.sep)[:ii+1])
        if cdir == '': continue         # absolute path -> /
        if not os.path.exists(cdir):
            os.mkdir(cdir)

pfile = tempfile.NamedTemporaryFile(suffix='.p', mode='wt')
pfile.write('ROUTINE-LEVEL ON ERROR UNDO, THROW.\n')

for base, dirs, files in os.walk('qstomp'):
    ensure_installdir(base)
    for file in files:
        if file.endswith('.cls') or file.endswith('.p') \
           and not file in ['testsend.p', 'sendread.p', 'SendMessage.p', 'ReadMessage.p']:
            pfile.write('COMPILE %s SAVE INTO %s.\n' % \
                               (os.path.join(base, file),
                                install_dir))
        elif not file.endswith('.i'):
            shutil.copyfile(os.path.join(base, file),
                            os.path.join(install_dir, base,file))
pfile.flush()
out = Popen([dlc+'/bin/mpro', '-b', '-p', pfile.name], stdout=PIPE)
errors = out.stdout.read()
if errors:
    raise Exception(errors)
