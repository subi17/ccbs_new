#!/usr/bin/env python
'''
Quick hacked-together script to convert a progress .df file containing
ONLY "add" commands into a gearbox migration .py file.
Created: 09/2010 Fabian Kreutz
'''

import sys
import re
import os
import itertools

rules = (
  re.compile('^ADD (?P<type>SEQUENCE) "(?P<name>.*)"$'),
  re.compile('^ADD (?P<type>TABLE) "(?P<name>.*)"$'),
  re.compile('^ADD (?P<type>FIELD) "(?P<name>.*)" OF "(?P<table>.*)" AS (?P<datatype>.*)$'),
  re.compile('^ADD (?P<type>INDEX) "(?P<name>.*)" ON "(?P<table>.*)"$'),
)


def read_body(gdict, fiter):
    for subline in fiter:
        if not subline: break
        option = subline.strip().split(' ', 1)
        key = option[0].lower().replace('-', '_')
        value = option[1] if len(option) == 2 else 'True'
        while value.startswith('"') and value.count('"') % 2 == 1:
            value += '\n' + next(fiter).strip()
        if value in ['yes', 'no']:
            value = '"%s"' % value
        if value.find('\n') > -1:
            value = value.replace('"', "'''")
        if key == 'index_field':
            if not key in gdict:
                gdict[key] = []
            index_field, direction = value.split(' ')
            index_field = index_field.replace('"', '')
            if direction == 'ASCENDING':
                gdict[key].append(index_field)
            else:
                gdict[key].append((index_field, 'DESC'))
        else:
            gdict[key] = value


def read_df(filename):
    sequences = []
    tables = {}
    fiter = (x.strip() for x in open(filename))
    for line in fiter:
        if line == '.':
            print('Done')
            break
        for gdict in (mm.groupdict() for mm in (rule.match(line) \
                                                for rule in rules) \
                                     if mm):
            read_body(gdict, fiter)
            if gdict['type'] == 'SEQUENCE':
                sequences.append(gdict)
            elif gdict['type'] == 'TABLE':
                if 'description' in gdict:
                    gdict['desc'] = gdict['description']
                    del gdict['description']
                tables[gdict['name']] = gdict
            else:
                table = tables[gdict['table']]
                table.setdefault(gdict['type'], []).append(gdict)
    return sequences, tables.values()


def prelude(classname):
    return ['from gearbox.migrations import Migration\n', '\n',
            'class {0}(Migration):\n'.format(classname), '\n']


indirect_attrs = ['name', 'type', 'table', 'datatype', 'index_field',
                  'FIELD', 'INDEX']
def csv_args(entity):
    args = ['\'{0}\''.format(entity['name'])]
    if 'datatype' in entity:
        args += ['\'{0}\''.format(entity['datatype'])]
    if 'index_field' in entity:
        args += ['{0}'.format(repr(entity['index_field']))]
    args += ['{0}={1}'.format(x, y) for x, y in entity.items() \
                                    if not x in indirect_attrs and y != '?']
    return ', '.join(args)


def write_sequences(db_name, sequences, filename):
    fd = open(filename, 'wt')
    fd.writelines(prelude('AddSequences'))
    fd.write('    database = "%s"\n\n' % db_name)
    fd.write('    def up(self):\n')
    for seq in sequences:
        fd.write('        self.sequence({0})\n'.format(csv_args(seq)))
    fd.write('\n    def down(self):\n')
    for seq in reversed(sequences):
        fd.write('        self.drop_sequence(\'{0}\')\n'.format(seq['name']))


def write_table(db_name, table, filename):
    fd = open(filename, 'wt')
    fd.writelines(prelude('AddTable{0}'.format(table['name'])))
    fd.write('    database = "%s"\n\n' % db_name)
    fd.write('    def up(self):\n')
    fd.write('        t = self.table({0})\n'.format(csv_args(table)))
    for fld in table.get('FIELD', []):
        fd.write('        t.column({0})\n'.format(csv_args(fld)))
    for idx in table.get('INDEX', []):
        fd.write('        t.index({0})\n'.format(csv_args(idx)))
    fd.write('\n    def down(self):\n')
    fd.write('        self.drop_table(\'{0}\')\n'.format(table['name']))


def main(df_file, index=1):
    db_name = os.path.basename(df_file).replace('.df', '')
    sequences, tables = read_df(df_file)
    if sequences:
        filename = '{0:04}_add_{1}_sequences.py'.format(index, db_name)
        print('Writing {0} ...'.format(filename))
        write_sequences(db_name, sequences, filename)
        index += 1
    for table in tables:
        filename = '{0:04}_add_table_{1}_{2}.py'.format(index, db_name,
                                                        table['name'].lower())
        print('Writing {0} ...'.format(filename))
        write_table(db_name, table, filename)
        index += 1


if __name__ == '__main__':
    assert len(sys.argv) >= 2, 'Syntax: dftopy.py <df-file> [start_idx]'
    args = sys.argv[1:]
    if len(args) == 1:
        main(args[0])
    else:
        main(args[0], int(args[1]))
