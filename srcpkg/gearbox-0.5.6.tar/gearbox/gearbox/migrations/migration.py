import os
import re
from .area_finder import AreaFinder
from .dict_with_action import DictWithAction

class Migration(object):
    '''Abstract superclass for all migrations.
New migrations must implement up() and down(). In these you can use:
    self.sequence(name, **args)
    self.alter_sequence(name, **args)
    self.drop_sequence(name)

    self.table(name, **args) -> tbl
    tbl.column(name, data_type, **args)
    or shortcuts:
      tbl.<DATATYPE>(name, **args)
      tbl.id(**args)
    tbl.index(name, *fields, **args)

    self.alter_table(name, **args) -> tbl
    tbl.alter_column(name, **args)
    tbl.drop_column(name)
    tbl.alter_index(name, [field, ...], **args)
    tbl.set_primary_index(name)
    tbl.rename_index(oldname, newname)
    tbl.alter_primary_index(name, [field, ...], **args)
        is deprecated
    tbl.drop_index(name)

    self.rename_table(oldname, newname)
    self.drop_table(name)
    
Example:
    class AddTableFooBar(Migration):
        database = 'common'
        def up(self):
            self.sequence('FooBarSeq')
            t = self.table('FooBar', help='Important data')
            t.id()
            t.char('baz', case_sensitive=True, format='x(30)')
            t.index('by_baz', ['baz'], unique=True, word=True)
            
        def down(self):
            self.drop_table('FooBar')
'''
    database = None
    encoding = 'utf-8'

    def __init__(self, num, name, a2t_cache, a2t_getter, devel=True):
        self.num = num
        self.name = name
        assert self.database, 'No database defined'
        def cached_or_get():
            if self.database not in a2t_cache:
                a2t_cache[self.database] = a2t_getter(self.database)
            return a2t_cache[self.database]
        self._afe = AreaFinder(cached_or_get).area_for_entity
        self._devel = devel
        self._actions = []

    def up(self):
        '''See documentation of the class.'''
        raise NotImplementedError()

    def down(self):
        '''See documentation of the class.'''
        raise NotImplementedError()

    def _migrate(self, dir):
        assert dir in ['up', 'down'], 'Unknown dir {0}'.format(dir)
        getattr(self, dir)()
        for table in (x for x in self._actions if x['TYPE'] == 'TABLE'):
            if table.action == 'create' \
            and (self._devel or not table['AREA']):
                table.data['AREA'] = self._afe(table, simul=table.simul)
            for index in table['INDEX']:
                if index.action == 'create' \
                and (self._devel or not index['AREA']):
                    index.data['AREA'] = self._afe(table, index, table.simul)
        return self._actions

    def table(self, tablename, simul=[], area=None,
                           label=None, desc=None, dump_name=None, **kwargs):
        '''table(name, simul=[], area=None, label=None, desc=None, dump_name=None) -> tbl
Create a new table and returns an object to access it.  The list `simul`
enumerates other (existing) tables that are usually accessed simultaneously.
The area manager tries to put these into different areas to optimize
hd-access. Alternatively in production mode, the area can be set.'''
        t = Table(tablename, 'create', simul, label=label,
                            description=desc, dump_name=dump_name, area=area, **kwargs)
        t._devel = self._devel  # blobs need this
        t._afe = self._afe
        self._actions.append(t)
        return t


    def alter_table(self, tablename, **kwargs):
        '''alter_table(name) -> tbl
Access an existing table (add/alter/drop columns/indexes).'''
        for key in kwargs:
            if not key in ['label','desc','dump_name','table_trigger']:
                raise Exception('Unknown option: ' + key)
	t = Table(tablename, 'alter', **kwargs)
        self._actions.append(t)
        return t


    def rename_table(self, oldname, newname):
        '''rename_table(oldname, newname)
Rename a table (but change no other arguments of it).'''
        t = Table(oldname, 'rename', newname=newname)
        self._actions.append(t)


    def drop_table(self, tablename):
        '''drop_table(name)
Removes a table and all it's fields and indexes.'''
        t = Table(tablename, 'drop')
        self._actions.append(t)


    def sequence(self, seqname, initial=0, increment=1, min_val=0,
                                       max_val=None, cycle_on_limit=False):
        '''sequence(name, initial=0, increment=1, min_val=0,
              max_val=None, cycle_on_limit=False)
Creates a new sequence with the given (optional) parameters.'''
        s = Sequence(seqname, 'create', initial=initial, increment=increment,
                                        min_val=min_val, max_val=max_val,
                                        cycle_on_limit=cycle_on_limit)
        self._actions.append(s)


    def alter_sequence(self, seqname, initial=None, increment=None,
                             min_val=None, max_val=None, cycle_on_limit=None):
        '''alter_sequence(name, **args)
Changes sequence attributes. For arguments see sequence()'''
        s = Sequence(seqname, 'alter', initial=initial, increment=increment,
                                        min_val=min_val, max_val=max_val,
                                        cycle_on_limit=cycle_on_limit)
        for k, v in list(s.data.items()):
            if v is None:
                del s.data[k]
        self._actions.append(s)

    def drop_sequence(self, seqname):
        '''drop_sequence(name)
Removes a sequence.'''
        s = Sequence(seqname, 'drop')
        self._actions.append(s)


class Sequence(DictWithAction):
    type = 'SEQUENCE'


class Field(DictWithAction):
    type = 'FIELD'


class Index(DictWithAction):
    type = 'INDEX'

    def __init__(self, name, action, *fields, **args):
        super(Index, self).__init__(name, action, **args)
        self.data['INDEX-FIELD'] = []
        for ff in fields:
            if isinstance(ff, str): ff = (ff, 'ASCENDING')
            self.data['INDEX-FIELD'].append(ff)


class Table(DictWithAction):
    '''Table access object for migrations.
Created via table or alter_table in a migration, can be used to add or (if
created via alter) alter/drop fields and indexes.'''
    type = 'TABLE'

    def __init__(self, name, action, simul=[], **args):
        super(Table, self).__init__(name, action, **args)
        self.data['FIELD'] = []
        self.data['INDEX'] = []
        self.simul = simul

    def id(self, **args):
        '''id(**args)
Adds an int64 field with the name TableId and a primary index to the table.
For args see column(), you can overwrite the name.'''
        defargs = {'name':self['NAME'] + 'Id', 'format':'->>>>>>>>>>9'}
        defargs.update(args)
        name = defargs['name']
        del defargs['name']
        self.column(name, 'int64', **args)
        self.index('id', name, primary=True, unique=True)

    def foreign_key(self, name, **args):
        '''foreign_key(name, **args)
Adds an int64 field to the table. For args see column().'''
        defargs = {'format':'->>>>>>>>>>9'}
        defargs.update(args)
        self.column(name, 'int64', **args)

    def int(self, name, **args):
        '''int(name, **args)
Adds an integer field to the table. For args see column().'''
        self.column(name, 'integer', **args)

    def char(self, name, **args):
        '''char(name, **args)
Adds a string field to the table. For args see column().'''
        self.column(name, 'character', **args)

    def log(self, name, **args):
        '''log(name, **args)
Adds a boolean field to the table. For args see column().'''
        self.column(name, 'logical', **args)

    def dec(self, name, **args):
        '''dec(name, **args)
Adds a decimal field to the table. For args see column().'''
        self.column(name, 'decimal', **args)

    def date(self, name, **args):
        '''date(name, **args)
Adds a date field to the table. For args see column().'''
        self.column(name, 'date', **args)

    def datetime(self, name, **args):
        '''datetime(name, **args)
Adds a datetime field to the table. For args see column().'''
        self.column(name, 'datetime', **args)

    def datetimetz(self, name, **args):
        '''datetimetz(name, **args)
Adds a datetime-tz field to the table. For args see column().'''
        self.column(name, 'datetime-tz', **args)


    def column(self, name, datatype, **args):
        '''column(name, datatype, **args)
Adds a new field to the table. Optional arguments are:
  format, initial, label, column_label, description, help, valexp,
    valmsg, view_as (with string value)
  position, max_width, order, extent, decimals
    (with integer value)
  mandatory, case_sensitive
    (with boolean value)
Large objects (blob and clob) additionally have
  lob_area, lob_size
    (with string values)
  collation, codepage
     (with string values, but clobs only)'''
        if datatype.endswith('lob'):
            self._add_default_lob_args(datatype, args)
        self._check_column_args(args)
        args.update({'DATA-TYPE': datatype, 'TABLE': self.data['NAME']})
        self.data['FIELD'].append(Field(name, 'create', **args))


    def alter_column(self, name, **args):
        '''alter_column(name, **args)
Changes attributes of an existing column. For arguments see column().  Only
valid if created via alter_table.'''
        assert self.action == 'alter', "Can't alter column in a new table"
        self._check_column_args(args)
        args.update({'TABLE': self.data['NAME']})
        self.data['FIELD'].append(Field(name, 'alter', **args))

    def rename_column(self, oldname, newname):
        '''rename_column(oldname, newname)
Rename a field (but change no other arguments of it).'''
        assert self.action == 'alter', "Can't rename column in a new table"
        args = {'TABLE': self.data['NAME'], 'NEWNAME':newname}
        self.data['FIELD'].append(Field(oldname, 'rename', **args))

    def drop_column(self, name):
        '''drop_column(name)
Remove the field from the table.  Only valid if created via alter_table.'''
        assert self.action == 'alter', "Can't drop column in a new table"
        args = {'TABLE': self.data['NAME']}
        self.data['FIELD'].append(Field(name, 'drop', **args))


    def index(self, name, fields, area=None,
                    primary=False, unique=False, word=False):
        '''index(name, fields, area=None, primary=False, unique=False, word=False)
Adds a new index to the table. The index fields are either the names or tuples
of the name and attributes, such as DESCENDING.
In production mode, the area can be forced.'''
        args = {'TABLE': self.data['NAME'], 'AREA':area}
        if primary: args['PRIMARY'] = None
        if unique: args['UNIQUE'] = None
        if word: args['WORD'] = None
        if not isinstance(fields, list):
            fields = [fields]
        index = Index(name, 'create', *fields, **args)
        self.data['INDEX'].append(index)


    def alter_index(self, name, fields, area=None,
                        primary=False, unique=False, word=False):
        '''alter_index(name, fields, area=None, primary=False, unique=False, word=False)
Drops an old index and creates a new one with the same name. No values (fields,
uniqueness) are copied from the original. You need to specify them again.'''
        assert self.action == 'alter', "Can't alter index in a new table"
        if primary:
            self.rename_index(name, "temp_" + name)
            self.index(name, fields, area=area, unique=unique, word=word)
            self.set_primary_index(name)
            self.drop_index("temp_" + name)
        else:
            self.drop_index(name)
            self.index(name, fields, area=area, unique=unique, word=word)


    def alter_primary_index(self, name, fields, unique=False, word=False):
        '''deprecated - you can use alter_index(primary=True) now'''
        import warnings
        warnings.warn("use alter_index(primary=True)", DeprecationWarning)
        self.alter_index(name, fields, primary=True, unique=unique, word=word)


    def set_primary_index(self, name):
        '''set_primary_index(name)
Make the index name the new primary index of this table.'''
        assert self.action == 'alter', "Can't alter index in a new table"
        args = {'TABLE': self.data['NAME']}
        self.data['INDEX'].append(Index(name, 'setpri', **args))


    def rename_index(self, oldname, newname):
        '''rename_index(oldname, newname)
Rename an index.'''
        assert self.action == 'alter', "Can't alter index in a new table"
        args = {'TABLE': self.data['NAME'], 'NEWNAME':newname}
        self.data['INDEX'].append(Index(oldname, 'rename', **args))


    def drop_index(self, name):
        '''drop_index(name)
Remove the index from the table.  Only valid if created via alter_table.'''
        assert self.action == 'alter', "Can't drop index in a new table"
        args = {'TABLE': self.data['NAME']}
        self.data['INDEX'].append(Index(name, 'drop', **args))


    def _check_column_args(self, args):
        for aa, vv in args.items():
            if aa in ['position', 'max_width', 'order', 'extent', 'decimals',
                      'lob_bytes']:
                if not isinstance(vv, int):
                    raise Exception('Value of %s must be an integer' % aa)
            elif aa in ['mandatory', 'case_sensitive']:
                if not isinstance(vv, bool):
                    raise Exception('Value of %s must be a boolean' % aa)
                if aa == 'mandatory' and not vv:
                    del args[aa]
                    args['null_allowed'] = None
                elif aa == 'case_sensitive' and not vv:
                    del args[aa]
                    args['not-case-sensitive'] = None
                else:
                    args[aa] = None
            elif aa in ['format', 'initial', 'label', 'column_label',
                        'help', 'valexp', 'valmsg', 'view_as', 'description',
                        'lob_size', 'lob_area',
                        'clob_collation', 'clob_codepage']:
                if vv is None:
                    args[aa] = NotImplemented
                elif not isinstance(vv, str):
                    raise Exception('Value of %s must be string' % aa)
            else:
                raise Exception('Unknown column argument: ' + aa)

    def _add_default_lob_args(self, datatype, args):
        csize = args.get('size', '100M')
        if 'size' in args: del args['size']
        bsize, unit = csize[:-1], csize[-1]
        if not bsize.isdigit() or not unit in 'KMG':
            raise Exception('lob-size `%s` is invalid; use e.g. `10M`' % csize)
        bsize = int(bsize) * pow(1024, ' KMG'.index(unit))
        args['lob_size'] = csize
        args['lob_bytes'] = bsize

        area = args.get('area')
        if 'area' in args: del args['area']
        if self._devel or not area:
            area = self._afe({'NAME': datatype + '-field',
                              'FIELD': [{'DATA-TYPE': datatype,
                                         'SIZE': bsize}]})
        args['lob_area'] = area

        if datatype == 'clob':
            args['clob_collation'] = args.get('collation', 'BASIC')
            if 'collation' in args: del args['collation']
            args['clob_codepage'] = args.get('codepage', 'UTF-8')
            if 'codepage' in args: del args['codepage']
        
