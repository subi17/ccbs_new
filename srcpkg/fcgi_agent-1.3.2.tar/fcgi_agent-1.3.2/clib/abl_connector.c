#include <sys/mman.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include "fcgiapp.h"
#include "abl_connector.h"

static int          initialized = 0;
static const char* header_fields[7] = {
        "REMOTE_ADDR",
        "PATH_INFO",
        "QUERY_STRING",
        "CONTENT_TYPE",
        "HTTP_AUTHORIZATION",
        "HTTP_USER_AGENT",
        "HTTP_ACCEPT" };
static const char* header_names[7] = {
        "IP", "Path", "Query", "Content-Type", "Auth", "User-Agent", "Accept" };
static const int header_lens[7] = { 20, 100, 1000, 100, 100, 100, 100 };

static FCGX_Request request;

// This should prevent the process memory pages ever to be swapped out, even
// if it's idle over night/the weekend
int lock_memory(void) {
    return mlockall(MCL_CURRENT | MCL_FUTURE);
}

int fetch_request(char *buf, int   maxlen, char *trace) {
	if (!initialized) {
		FCGX_Init();
                initialized = 1;
        }

	if (FCGX_InitRequest(&request, 0, 0) != 0)
		return E_INIT_ERROR;

	if (FCGX_Accept_r(&request) < 0)
		return E_ACCEPT_FAILED;

        int bytes;
        const char *request_method = FCGX_GetParam("REQUEST_METHOD", request.envp);

        if (strcmp(request_method, "GET") == 0 ||
            strcmp(request_method, "DELETE") == 0) {
                bytes = 0;
        } else {
            const char *content_length_str = FCGX_GetParam("CONTENT_LENGTH", request.envp);

            if (!content_length_str) {
                    FCGX_Finish_r(&request);
                    return E_NO_CONTENT_LENGTH;
            }

            size_t content_length = strtoul(content_length_str, NULL, 10);

            if (content_length > maxlen)
                    return E_CONTENT_TOO_LONG;

            bytes = FCGX_GetStr(buf, maxlen, request.in);

            if (bytes < 0)
                    return E_READ_ERROR;
            else if (bytes == 0)
                    return E_EOF;
        }

        char *header_param;
        int curlen = 0;
        int fieldlen, ii;
        trace[0] = '\0';
        strcat(trace, "method=");
        strncat(trace, request_method, 6);
        curlen = strlen(trace);
        for (ii=0; ii<6; ++ii) {
            header_param = FCGX_GetParam(header_fields[ii], request.envp);
            if (!header_param) continue;
            fieldlen = strlen(header_param);
            if (fieldlen > header_lens[ii]) continue;

            trace[curlen] = 30;
            curlen += 1;
            trace[curlen] = '\0';
            strcat(trace + curlen, header_names[ii]);
            strcat(trace + curlen, "=");
            strncat(trace + curlen, header_param, fieldlen);
            curlen += strlen(header_names[ii]) + 1 + fieldlen;
        }

	return bytes;
}


int send_response(const char *header,
                  const char *buf,
                  int         len) {
    int err = 0;
    if (FCGX_PutS(header, request.out) < 0 ||
        FCGX_PutS("\r\n", request.out) < 0 ||
        FCGX_PutStr(buf, len, request.out) < 0) {
        err = E_WRITE_ERROR;
    }
    FCGX_Finish_r(&request);
    return err;
}
