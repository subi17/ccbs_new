#ifdef HAVE_CONFIG_H
# include <config.h>
#endif

#include <sys/mman.h>

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <fcgiapp.h>

#include "nq_conn.h"

static int          initialized = 0;

static FCGX_Request request;


int
lock_me(void)
{
	return mlockall(MCL_CURRENT | MCL_FUTURE);
}

int
fetch_request(char *buf,
	      int   maxlen,
              char *trace)
{
	if (!initialized)
		FCGX_Init();

	if (FCGX_InitRequest(&request, 0, 0) != 0)
		return E_INIT_ERROR;

	if (FCGX_Accept_r(&request) < 0)
		return E_ACCEPT_FAILED;

	const char *content_length_str = FCGX_GetParam("CONTENT_LENGTH", request.envp);

	if (!content_length_str) {
		FCGX_Finish_r(&request);
		return E_NO_CONTENT_LENGTH;
	}

	size_t content_length = strtoul(content_length_str, NULL, 10);

	if (content_length > maxlen)
		return E_CONTENT_TOO_LONG;

	int bytes = FCGX_GetStr(buf, maxlen, request.in);

	if (bytes < 0)
		return E_READ_ERROR;
	else if (bytes == 0)
		return E_EOF;

        trace[0] = '\0';
        char *header_ui = FCGX_GetParam("HTTP_X_ENDUSERIDENTIFICATION", request.envp);
        char *header_ua = FCGX_GetParam("HTTP_USER_AGENT", request.envp);
        char *header_ip = FCGX_GetParam("REMOTE_ADDR", request.envp);
        char *header_au = FCGX_GetParam("HTTP_AUTHORIZATION", request.envp);
        if (!header_ui) { header_ui = ""; }
        if (!header_ua) { header_ua = ""; }
        if (!header_ip) { header_ip = ""; }
        if (!header_au) { header_au = ""; } else { header_au += 6; }
        strncat(trace, header_ip, 100);
        strcat(trace, ",");
        strncat(trace, header_au, 100);
        strcat(trace, ",");
        strncat(trace, header_ui, 100);
        strcat(trace, ",");
        strncat(trace, header_ua, 100);

	return bytes;
}

int
send_response(const char *content_type,
	      const char *buf,
	      int         len)
{
	int err = 0;

	if (FCGX_PutS("Content-Type: ", request.out) < 0
            || FCGX_PutS(content_type, request.out) < 0
            || FCGX_PutS("\r\n\r\n", request.out) < 0
            || FCGX_PutStr(buf, len, request.out) < 0) {
                err = E_WRITE_ERROR;
        }

	FCGX_Finish_r(&request);

	return err;
}

int
send_unauthorized(const char *realm)
{
    int err = 0;
    if (FCGX_PutS("Status: 401 UNAUTHORIZED\r\n", request.out) < 0
            || FCGX_PutS("WWW-Authenticate: Basic realm=\"", request.out) < 0
            || FCGX_PutS(realm, request.out) < 0
            || FCGX_PutS("\"\r\n\r\n", request.out) < 0) {
        err = E_WRITE_ERROR;
    }

    FCGX_Finish_r(&request);

    return err;
}
