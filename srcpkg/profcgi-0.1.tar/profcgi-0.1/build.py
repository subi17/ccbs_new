#!/usr/bin/python
'''
Installation script meant for use via the PyCCBS
'''

import os
import subprocess
relpath = '../..'

if os.path.exists(relpath + '/etc/make_site.py'):
    exec(open(relpath + '/etc/make_site.py').read())

tools_dir = os.environ['PREFIX']

os.symlink('.', 'fcgi_agent')
subprocess.call(['gmake', 'install', '--quiet',
                        'TOOLS_DIR=%s' % tools_dir,
                        'DLC_PATH=%s' % os.environ['DLC']
                ])
