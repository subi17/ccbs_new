#include <sys/mman.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include "fcgiapp.h"
#include "abl_connector.h"

static int initialized = 0;

static FCGX_Request request;

// This should prevent the process memory pages ever to be swapped out, even
// if it's idle over night/the weekend
int lock_memory(void) {
    return mlockall(MCL_CURRENT | MCL_FUTURE);
}

int fetch_request(char *buf,
                  int   maxlen,
                  char *hdr,
                  int  *hdrlen) {

    if (!initialized) {
        FCGX_Init();
        initialized = 1;
    }

	if (FCGX_InitRequest(&request, 0, 0) != 0)
		return E_INIT_ERROR;

	if (FCGX_Accept_r(&request) < 0)
		return E_ACCEPT_FAILED;

    int bytes = 0;
    const char *request_method = FCGX_GetParam("REQUEST_METHOD", request.envp);

    if (strcmp(request_method, "GET") != 0 &&
        strcmp(request_method, "DELETE") != 0) {

        const char *content_length_str = FCGX_GetParam("CONTENT_LENGTH", request.envp);

        if (!content_length_str) {
            FCGX_Finish_r(&request);
            return E_NO_CONTENT_LENGTH;
        }

        size_t content_length = strtoul(content_length_str, NULL, 10);

        if (content_length > maxlen)
            return E_CONTENT_TOO_LONG;

        bytes = FCGX_GetStr(buf, maxlen, request.in);

        if (bytes < 0)
            return E_READ_ERROR;

        if (bytes == 0)
            return E_EOF;
    }

    char **header_param;
   
    int paramlen = 0;
    int totallen = 0;

    for (header_param = request.envp; *header_param; ++header_param) {

        if (totallen > 0) {
            *hdr = 30;
            hdr++;
            totallen++;
        }

        paramlen = strlen(*header_param);
        totallen += paramlen;

        if ((totallen + 1) > *hdrlen)
            return E_HEADER_TOO_LONG;

        memcpy(hdr, *header_param, paramlen);
        hdr += paramlen;
    }

    *hdr = '\0';

    *hdrlen = totallen;

	return bytes;
}

int send_response(const char *header,
                  int         hdrlen,
                  const char *buf,
                  int         len) {
    int err = 0;
    if (FCGX_PutStr(header, hdrlen, request.out) < 0 ||
        FCGX_PutStr(buf, len, request.out) < 0) {
        err = E_WRITE_ERROR;
    }
    FCGX_Finish_r(&request);
    return err;
}

int send_header_only_response(const char *header,
                              int         hdrlen) {
    int err = 0;
    if (FCGX_PutStr(header, hdrlen, request.out) < 0) {
        err = E_WRITE_ERROR;
    }
    FCGX_Finish_r(&request);
    return err;
}
