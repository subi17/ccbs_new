from .dict_with_action import DictWithAction

class HumanReadableFormatter():
    '''Formatter for human readable output during migration processing.'''

    def show_steps(self, data):
        '''show_steps(data)
Renders the migration's df (as DictWithAction) in human-readable form.'''
        result = ''
        for item in data:
            assert isinstance(item, DictWithAction)
            action, type, name = (item.action.capitalize(),
                                  item['TYPE'].lower(),
                                  item['NAME'])
            result += '  %s %s %s' % (action, type, name)
            if item.action != 'drop' and type == 'table':
                result += ' (\n'
                dir = {'create': ' + ' if item.action == 'alter' else '',
                       'alter': '<> ',
                       'rename': '   ',
                       'setpri': '1! ',
                       'drop': ' - '}
                for fi in item['FIELD'] + item['INDEX']:
                    result += '    ' + dir[fi.action]
                    result += fi['TYPE'].lower() + ' '
                    result += fi['NAME']
                    if fi.get('DATA-TYPE'):
                        result += ': ' + fi['DATA-TYPE']
                    if fi.get('NEWNAME'):
                        result += ' -> ' + fi['NEWNAME']
                    result += '\n'
                result += '  )\n'
            else:
                result += '\n'
        return result
