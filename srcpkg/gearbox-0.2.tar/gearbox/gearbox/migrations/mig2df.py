#!/bin/env python

import sys
import os
from gearbox.migrations.migration import Migration
from gearbox.migrations.dumpfile_formatter import DumpfileFormatter
from gearbox.migrations.hr_formatter import HumanReadableFormatter

out = sys.stdout
err = sys.stderr

def instantiate_mig(migfile, db_dir):
    migbase = os.path.basename(migfile)
    mignum, migname = migbase.split('_', 1)
    if mignum == 'monthly':
        mignum = 0
    else:
        mignum = int(mignum)
    migname = migname.split('.')[0]
    locals = {}
    try:
        exec(open(migfile).read(), {}, locals)
    except SyntaxError as se:
        _type, line, _char, excerpt = se.args[1]
        raise Exception('Syntax error in line %d of migration %s:\n%s' % \
                            (line, migbase, excerpt))
    for k, v in locals.items():
        if issubclass(v, Migration) and v != Migration:
            return v(mignum, migname, db_dir)
    raise Exception("No Migration defined in file")


def main(migfile, dir, db_dir):
    if not os.path.exists(migfile):
        raise Exception("Migration not found")
    if not dir in ('up', 'down'):
        raise Exception("Direction not recognized")
    if not os.path.isdir(db_dir):
        raise Exception("Database dir not found")

    mig = instantiate_mig(migfile, db_dir)
    err.write(dir.capitalize() + "grading migration " + \
          str(mig.num) + ": " + mig.__class__.__name__ + "\n")
    if dir == 'up':
        mig.up()
    else:
        mig.down()
    if not mig._actions: sys.exit(0)

    err.write(HumanReadableFormatter().show_steps(mig._actions))
    if hasattr(mig, 'dumped_on') and getattr(mig, 'dumped_on') == os.uname()[1]:
        err.write('This migration was dumped here - skipping')
    else:
        out.write(DumpfileFormatter().format_df(mig._actions) + '\n')


if __name__ == '__main__':
    migfile, dir, db_dir = sys.argv[1:4]
    main(migfile, dir, db_dir)
