import sys
from .dict_with_action import DictWithAction

class DumpfileFormatter():
    '''Formatter for progress-readable dump or structure files (.df/.st).
    It's only internally used for db creation (.st from StructureConfig) and
    migrations (.df from Migration).'''

    def _pvalue(self, value):
        if isinstance(value, bool):
            return ['no', 'yes'][value]
        elif isinstance(value, int):
            return str(value)
        elif value is NotImplemented:
            return '?'
        elif value is None:
            return ''
        else:
            return '"%s"' % value.replace('"', '""')

    def render_entity(self, item, action):
        '''Render one entity (sequence, table, field or index) of a dump file.
        For tables only the header is rendered, no sub-entities.'''
        at = {'create': 'ADD', 'alter': 'UPDATE', 'drop': 'DELETE',
              'rename': 'RENAME', 'setpri':'UPDATE PRIMARY'}
        txt = '%s %s "%s"' % (at[action], item['TYPE'], item['NAME'])
        result = ''
        if item['TYPE'] == 'FIELD':
            txt += ' OF "%s"' % item['TABLE']
            if action == 'create':
                txt += ' AS %s' % item['DATA-TYPE']
            elif action == 'rename':
                txt += ' TO "%s"' % item['NEWNAME']
        elif item['TYPE'] == 'INDEX':
            if action == 'rename':
                txt += ' TO "%s"' % item['NEWNAME']
            txt += ' ON "%s"' % item['TABLE']

        result += txt + '\n'
        for attr in sorted(item.keys()):
            if attr in ['TYPE', 'NAME', 'TABLE', 'DATA-TYPE',
                        'FIELD', 'INDEX', 'NEWNAME']:
                continue
            elif attr == 'INDEX-FIELD':
                for name, dir in item[attr]:
                    result += '  INDEX-FIELD "%s" %s\n' % (name, dir)
            else:
                result += '  %s %s\n' % (attr, self._pvalue(item[attr]))
        return result + '\n'


    def format_df(self, data):
        '''format_df(data) -> str
        Formats the data as .df file. The items of the data are expected
        to be DictWithAction types, as produced by the migrations.'''
        result = ''
        for item in data:
            assert item['TYPE'] != 'AREA', "Can't format st as df"
            action = item.action if isinstance(item, DictWithAction) else 'create'
            if action != 'alter' or item['TYPE'] != 'TABLE' \
            or ([x for x in item.data.keys() \
                   if x not in ['INDEX', 'FIELD', 'NAME', 'TYPE']]):
                # table alter only dumped when table-attr is changed (eg. help)
                result += self.render_entity(item, action)
            if item['TYPE'] == 'TABLE':
                for ff in item['FIELD']:
                    result += self.render_entity(ff, ff.action)
                for ii in item['INDEX']:
                    result += self.render_entity(ii, ii.action)
        return result

