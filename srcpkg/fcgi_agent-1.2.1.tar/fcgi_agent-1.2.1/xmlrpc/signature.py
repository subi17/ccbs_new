class ZipArray(list):
    def __mul__(self, other):
        other = other.replace("[","|").replace("]","").split("|")
        result = []
        for x in (self or [[]]):
            for y in other:
                result.append(x + [y])
        return ZipArray(result)

import re
from sys import stdin, stderr, argv

r1 = re.compile(r'validate_request\s*\(\s*param_toplevel_id\s*,\s*["\']([\w\[\],\|]+)["\']\s*\)', re.M | re.S)
r2 = re.compile(r'add_(\w+)\s*\(\s*response_toplevel_id', re.M | re.S)

input = open(argv[1]).read()
mm = r1.search(input)
if mm: mm = mm.group(1)
else: mm = ''
try:
    r = ZipArray([[r2.search(input).group(1)]])
    for x in mm.split(","): r *= x
    print '\n'.join([','.join([y for y in x if y]).strip(",") for x in r])
except StandardError, e:
    stderr.write("Did not match add_*(response_toplevel_id\n")
