/*
 * abl_connector - Newton framework request fetch from proxy (socket)
 * Author: Fabian Kreutz 10/2005, Olli Helenius 05/2007
 *
 * Purpose: These two library functions shall be invoked by Progress
 *          to fetch an xmlrpc request from a well-known FastCGI-socket.
 *          A second function returns a response to the same socket.
 *
 * Functionality:
 *          Actually it's much more general. The request data is text and
 *          need not be xml and since it's a library function, it need not
 *          be called by Progress, but can be invoked by anything.
 *
 * Implementation:
 * 	    Whenever something unplanned happens, the connection is closed
 * 	    and a negative value is returned, so that the application can
 * 	    issue a log-message. On next try the connection will be
 * 	    re-established. Exception: A request that is too large.
 */

enum errcodes {
	E_ACCEPT_FAILED       = -1,
	E_NO_CONTENT_LENGTH   = -2,
	E_CONTENT_TOO_LONG    = -3,
	E_INCOMPLETE_READ     = -4,
	E_EOF                 = -5,
	E_WRITE_ERROR         = -6,
	E_READ_ERROR          = -7,
	E_INIT_ERROR          = -8,
    E_HEADER_TOO_LONG     = -9,
};

#ifdef __cplusplus
extern "C" {
#endif

    /* Fetches one request from the remote queue into buf.
     * The buffer must be allocated externally to at least maxlen bytes.
     * Trace is assumed to be at least 302 bytes long and will receive
     * all HTTP headers.
     * Returns a negative value on error. */
    int fetch_request(char *buf, int maxlen, char *hdr, int *hdrlen);

    /* Sends the response with header from header (hdrlen bytes of that) and data
     * from buf (len bytes of that).
     * Returns a negative value on error. */
    int send_response(const char *header, int hdrlen, const char *buf, int len);

    /* Sends the response with header from header (hdrlen bytes of that)
     * Returns a negative value on error. */
    int send_header_only_response(const char *header, int hdrlen);
    
#ifdef __cplusplus
}
#endif
