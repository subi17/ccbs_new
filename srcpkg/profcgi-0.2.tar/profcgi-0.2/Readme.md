# profcgi - RPC and REST server for Progress OpenEdge(tm)

A JsonRPC 2.0 is fully supported. XML-RPC is not currently implemented (only tiny parts are).

The REST solution is based on https://github.com/consultingwerk/ADE-Sourcecode/blob/master/src/netlib/OpenEdge/Web/WebHandler.cls
This should be easier to use however

## Build process

Call

    make clean
    make dist

to produce a tarball that can be installed in a pCCBS by pike.

The pCCBS srcpkg targets will call build.py, which compiles the code into
a directory $PREFIX/tools/profcgi.

## TODO

Proper documentation and lot of minor tweaking is possible.

## Author
Tatu Lamminmäki
